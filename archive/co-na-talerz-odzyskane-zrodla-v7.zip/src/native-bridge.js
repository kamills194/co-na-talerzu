import { Capacitor } from '@capacitor/core';
import { Preferences } from '@capacitor/preferences';
import { Share } from '@capacitor/share';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
const isNative = Capacitor.isNativePlatform();
const keys = ['cnt-shopping', 'cnt-favorites', 'cnt-plan', 'cnt-language','cnt-community-draft'];
const ready = isNative ? Promise.all(keys.map(async key => {
  try { const { value } = await Preferences.get({ key }); if (value !== null) localStorage.setItem(key, value); }
  catch { /* The app can still use its local working copy. */ }
})) : Promise.resolve();
let writeQueue = Promise.resolve();
window.CNTNative = {
  isNative,
  ready,
  persist(key, value) {
    if (!isNative || !keys.includes(key)) return Promise.resolve();
    writeQueue = writeQueue.catch(() => {}).then(() => Preferences.set({ key, value }));
    return writeQueue;
  },
  async share(text) {
    if (isNative) return Share.share({ title: (window.t?.('Lista zakupów')||'Shopping list')+' — Co na talerz', text, dialogTitle: window.t?.('Udostępnij')||'Share' });
    if (navigator.share) return navigator.share({ title: (window.t?.('Lista zakupów')||'Shopping list')+' — Co na talerz', text });
    throw new Error('share-unavailable');
  },
  async feedback() { if (isNative) try { await Haptics.impact({ style: ImpactStyle.Light }); } catch {} },
  async clear() {
    if (isNative) {
      await writeQueue.catch(() => {});
      await Promise.all(keys.filter(key => key !== 'cnt-language').map(key => Preferences.remove({ key })));
    }
    keys.filter(key => key !== 'cnt-language').forEach(key => localStorage.removeItem(key));
  }
};
