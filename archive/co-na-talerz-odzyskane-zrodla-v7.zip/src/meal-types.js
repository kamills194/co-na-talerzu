// Meal occasions are editorial navigation choices, separate from source cuisine/ingredients.
export const MEAL_TYPES = [
 {id:'breakfast',label:'Śniadania',singular:'Śniadanie',hint:'Dobry początek dnia',mark:'01'},
 {id:'second-breakfast',label:'Drugie śniadania',singular:'Drugie śniadanie',hint:'Na mały głód i na wynos',mark:'02'},
 {id:'lunch',label:'Obiady',singular:'Obiad',hint:'Główny posiłek dnia',mark:'03'},
 {id:'dessert',label:'Desery',singular:'Deser',hint:'Coś na słodko',mark:'04'},
 {id:'starter',label:'Przystawki',singular:'Przystawka',hint:'Małe dania na początek',mark:'05'},
 {id:'dinner',label:'Kolacje',singular:'Kolacja',hint:'Smaczne zakończenie dnia',mark:'06'}
];
const groups={
 breakfast:['3','8','12','25','29','mealdb-52965','mealdb-53430','mealdb-52969','mealdb-53036','mealdb-53159'],
 'second-breakfast':['7','9','10','11','30','mealdb-52855','mealdb-53060','mealdb-53080','mealdb-53290'],
 starter:['21','26','mealdb-52913','mealdb-52779','mealdb-53072','mealdb-53438','mealdb-53169','mealdb-53525','mealdb-53094','mealdb-53526','mealdb-53256','mealdb-53428','mealdb-53282','mealdb-53559','mealdb-53440','mealdb-53284'],
 dinner:['17','19','20','22','23','24','mealdb-52830','mealdb-52831','mealdb-52939','mealdb-52870','mealdb-53157','mealdb-53239','mealdb-53107','mealdb-53158','mealdb-53267','mealdb-53278','mealdb-53185','mealdb-53283']
};
const assignments=new Map(Object.entries(groups).flatMap(([meal,ids])=>ids.map(id=>[id,meal])));
export function categoryOf(recipe){return assignments.get(String(recipe.id))||(MEAL_TYPES.some(type=>type.id===recipe.meal)?recipe.meal:'lunch');}
export function matchesRecipeDiet(recipe,diet){
 if(diet==='all')return true;
 const names=recipe.ingredients.map(i=>i.name.toLocaleLowerCase('pl')).join(' | ')+' | '+(recipe.name||'').toLocaleLowerCase('pl')+' | '+(recipe.translations?.pl?.name||'').toLocaleLowerCase('pl');
 const meat=/\bbeef\b|\blamb\b|\bpork\b|\bchicken\b|\bbacon\b|\bham\b|\bsausages?\b|prosciutto|chorizo|\bsuet\b|goose fat|kielbasa|black pudding|kurczak|wołow|wieprz|jagnię|boczek|szynka|kiełbas/.test(names.replace(/beef tomatoes/gi,''));
 const fish=/saltfish|\bfish\b|salmon|\bcod\b|\btuna\b|prawns?|squid|clams?|oysters?|seafood|barramundi|łosoś|dorsz|tuńczyk|krewet|kalmar|małż|ostryg/.test(names);
 const dairy=/\bmilk\b|\bcream\b|\bbutter\b|cheese|yogurt|yoghurt|\bbrie\b|cheddar|\bfeta\b|gruyere|stilton|emmental|fromage|masło|\bmleko\b|śmietan|jogurt|\bser\b|twaróg/.test(names.replace(/coconut milk|mleczko kokosowe|peanut butter|butter beans/gi,''));
 const eggHoney=/\beggs?\b|jaj|miód|honey/.test(names);
 if(diet==='veg')return !meat&&!fish;
 if(diet==='vegan')return !meat&&!fish&&!dairy&&!eggHoney;
 if(diet==='meat')return meat;
 if(diet==='fish')return fish;
 if(diet==='dairy-free')return !dairy;
 if(diet==='protein-free')return recipe.nutrition?.verified===true&&recipe.nutrition.proteinPerServing===0;
 return false;
}
