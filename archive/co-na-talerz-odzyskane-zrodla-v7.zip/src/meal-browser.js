import {MEAL_TYPES,categoryOf,matchesRecipeDiet} from './meal-types.js';
globalThis.CNTMeals={types:MEAL_TYPES,categoryOf,matchesDiet:matchesRecipeDiet,matchesRecipeDiet};
