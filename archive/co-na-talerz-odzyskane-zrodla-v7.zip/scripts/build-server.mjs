import {build} from 'esbuild';
import fs from 'node:fs/promises';
import path from 'node:path';
const assets={};const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
await fs.mkdir('outputs',{recursive:true});await fs.rm('web-build',{recursive:true,force:true});await fs.mkdir('web-build',{recursive:true});
async function collect(dir){for(const entry of await fs.readdir(dir,{withFileTypes:true})){if(entry.name==='server'||entry.name.startsWith('.')||entry.name.includes('qa'))continue;const file=path.join(dir,entry.name);if(entry.isDirectory())await collect(file);else{const rel=path.relative('dist',file);assets['/'+rel]={type:types[path.extname(file)]||'application/octet-stream',data:(await fs.readFile(file)).toString('base64')};await fs.mkdir(path.dirname(path.join('web-build',rel)),{recursive:true});await fs.copyFile(file,path.join('web-build',rel));}}}
await collect('dist');await fs.writeFile('outputs/assets.generated.js','export default '+JSON.stringify(assets));
await build({entryPoints:['worker/index.js'],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'dist/server/index.js',minify:true});console.log('Worker and native web assets built.');
