"""Import a bounded, attributed development catalogue from official API responses.
Never redistribute third-party method text. Raw quantities are preserved verbatim.
Before an app-store release, obtain the provider's production subscription and review artwork rights.
"""
from pathlib import Path
import json,urllib.parse,argparse
parser=argparse.ArgumentParser()
parser.add_argument("responses",type=Path,help="Selected official API responses JSON")
parser.add_argument("titles",type=Path,help="Polish titles TSV: provider ID, title")
args=parser.parse_args()
source=args.responses
selected=json.loads(source.read_text())
titles=dict(line.split('\t',1) for line in args.titles.read_text().splitlines())
cat_pl={'Beef':'Wołowina','Chicken':'Kurczak','Pork':'Wieprzowina','Lamb':'Jagnięcina','Seafood':'Ryby i owoce morza','Dessert':'Desery','Vegetarian':'Wegetariańskie','Vegan':'Wegańskie','Starter':'Przystawki','Breakfast':'Śniadania','Side':'Dodatki','Miscellaneous':'Inne'}
result=[]
for meal in selected:
 category=meal['strCategory'];original=meal['strMeal'].strip();meal_id=meal['idMeal']
 ingredients=[{'name':(meal.get('strIngredient'+str(i)) or '').strip(),'nameEn':(meal.get('strIngredient'+str(i)) or '').strip(),'rawMeasure':(meal.get('strMeasure'+str(i)) or '').strip(),'qty':1,'unit':''} for i in range(1,21) if (meal.get('strIngredient'+str(i)) or '').strip()]
 original_url=meal['strSource'].strip();photo=meal['strMealThumb'];assert urllib.parse.urlparse(photo).hostname in ['www.themealdb.com','themealdb.com']
 record={'id':'mealdb-'+meal_id,'name':original,'desc':category+' · TheMealDB','originalLanguage':'en','translations':{'en':{'name':original,'desc':category+' · TheMealDB','steps':[]},'pl':{'name':titles[meal_id],'desc':cat_pl.get(category,category)+' · przepis ze źródła','steps':[]}},'ingredients':ingredients,'ingredientLanguage':'en','steps':[],'time':None,'baseServings':None,'scalable':False,'meal':'breakfast' if category=='Breakfast' else 'dessert' if category=='Dessert' else 'lunch','diet':'veg' if category in ['Vegetarian','Vegan'] else 'fish' if category=='Seafood' else 'meat' if category in ['Beef','Chicken','Pork','Lamb'] else 'other','category':category,'area':meal.get('strArea') or meal.get('strCountry') or None,'photo':{'url':photo,'credit':'TheMealDB','creditUrl':'https://www.themealdb.com/','licenseStatus':'development-api','creativeCommonsConfirmed':meal.get('strCreativeCommonsConfirmed')},'source':{'url':original_url,'publisher':'TheMealDB','author':urllib.parse.urlparse(original_url).hostname,'checkedAt':'2026-11-15','kind':'catalog-reference','providerId':meal_id},'bg':'#edf0e7'}
 uk_path=Path('store/catalog-titles-uk.tsv')
 if uk_path.exists():
  uk_titles=dict(line.split('\t',1) for line in uk_path.read_text().splitlines())
  if meal_id in uk_titles:record['translations']['uk']={'name':uk_titles[meal_id],'desc':'Страва з джерела · повний рецепт у видавця','steps':[]}
 result.append(record)
assert len(result)==90
Path('dist/catalog.js').write_text('recipes.push(...'+json.dumps(result,ensure_ascii=False,separators=(',',':'))+');\n')
Path('store/catalog-provenance.json').write_text(json.dumps({'provider':'TheMealDB','mode':'private-development','fetchedAt':'2026-11-15','count':len(result),'terms':'https://www.themealdb.com/terms_of_use.php','containsFullThirdPartyMethods':False,'originalServingsAndTimesProvided':False,'records':[{'id':r['id'],'source':r['source']['url'],'photo':r['photo']['url'],'photoCredit':r['photo']['credit'],'creativeCommonsConfirmed':r['photo']['creativeCommonsConfirmed']} for r in result]},ensure_ascii=False,indent=2)+'\n')
print('Imported',len(result),'catalogue references with real dish photographs')
