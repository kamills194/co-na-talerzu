// Credentials only arrive on stdin; no tokens in argv, files or output.
import readline from 'node:readline/promises';
const io=readline.createInterface({input:process.stdin,output:process.stdout});
const input=JSON.parse(await io.question(''));io.close();
const base=new URL(input.base);if(base.protocol!=='https:'||base.hostname!=='co-na-talerz-kamil.przestrze-ro-2040.chatgpt.site')throw Error('Unexpected Site origin');
const path=input.path||'/api/bot/run';if(!['/api/bot/run','/api/bot/instructions','/api/promotions'].includes(path))throw Error('Unexpected path');
const headers={'OAI-Sites-Authorization':'Bearer '+input.token,'X-CNT-Update-Key':input.token};
if(path==='/api/bot/run')headers['Content-Type']='application/json';
const r=await fetch(new URL(path,base),{method:path==='/api/bot/run'?'POST':'GET',headers,body:path==='/api/bot/run'?JSON.stringify({offers:input.offers||[],...(input.observations?{observations:input.observations}:{})}):undefined,redirect:'error',signal:AbortSignal.timeout(90000)});console.log(JSON.stringify({status:r.status,result:await r.json()}));if(!r.ok)process.exitCode=1;
