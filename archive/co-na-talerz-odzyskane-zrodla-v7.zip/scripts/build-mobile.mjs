import { build } from 'esbuild';
await build({ entryPoints: ['src/native-bridge.js'], bundle: true, format: 'iife', target: ['safari15','chrome100'], outfile: 'dist/native-bridge.js', minify: true, legalComments: 'eof' });
console.log('Native bridge built; web assets ready.');
await build({ entryPoints: ['src/meal-browser.js'], bundle: true, format: 'iife', target: ['safari15','chrome100'], outfile: 'dist/meal-categories.js', minify: true });
