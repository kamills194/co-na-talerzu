CREATE TABLE `login_nonces` (
	`hash` text PRIMARY KEY NOT NULL,
	`expires_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `login_sessions` (
	`hash` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`expires_at` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `login_session_expiry` ON `login_sessions` (`expires_at`);--> statement-breakpoint
CREATE TABLE `login_users` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `promo_offers` (
	`id` text PRIMARY KEY NOT NULL,
	`store_id` text NOT NULL,
	`name` text NOT NULL,
	`ingredient_key` text,
	`price_cents` integer NOT NULL,
	`unit` text NOT NULL,
	`start_date` text NOT NULL,
	`end_date` text NOT NULL,
	`conditions` text NOT NULL,
	`scope` text NOT NULL,
	`source_url` text NOT NULL,
	`evidence` text NOT NULL,
	`checked_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `promo_dates_idx` ON `promo_offers` (`start_date`,`end_date`);--> statement-breakpoint
CREATE TABLE `promo_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`started_at` text NOT NULL,
	`finished_at` text,
	`status` text NOT NULL,
	`summary_json` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `promo_sources` (
	`store_id` text PRIMARY KEY NOT NULL,
	`url` text NOT NULL,
	`status` text NOT NULL,
	`content_hash` text,
	`checked_at` text NOT NULL,
	`changed_at` text,
	`leaflets_json` text NOT NULL,
	`message` text NOT NULL
);
