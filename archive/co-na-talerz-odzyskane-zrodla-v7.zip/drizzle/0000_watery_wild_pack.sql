CREATE TABLE `community_blocks` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`blocked_author_id` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `community_block_unique` ON `community_blocks` (`user_id`,`blocked_author_id`);--> statement-breakpoint
CREATE TABLE `community_recipes` (
	`id` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`author` text NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`ingredients_json` text NOT NULL,
	`steps_json` text NOT NULL,
	`servings` integer NOT NULL,
	`minutes` integer NOT NULL,
	`diet` text NOT NULL,
	`language` text DEFAULT 'pl' NOT NULL,
	`photo_key` text,
	`status` text DEFAULT 'published' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `community_published_idx` ON `community_recipes` (`status`,`created_at`);--> statement-breakpoint
CREATE INDEX `community_owner_idx` ON `community_recipes` (`owner_id`);--> statement-breakpoint
CREATE TABLE `community_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`recipe_id` text NOT NULL,
	`reporter_id` text NOT NULL,
	`reason` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `community_report_unique` ON `community_reports` (`recipe_id`,`reporter_id`);