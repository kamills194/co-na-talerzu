# Co na talerz

Aplikacja do wybierania i planowania posiłków. Wersja 0.4.0 ma 30 przepisów, filtry, ulubione, zmianę liczby porcji, siedmiodniowy plan i wspólną listę zakupów. Wersja webowa działa jako instalowalna PWA; projekty iOS i Android pakują interfejs i przepisy lokalnie.

## Rozwój

- `npm ci` — instalacja zależności.
- `npm run build` — generowanie mostka natywnych funkcji; pozostałe pliki są buildless.
- `npm test` — testy logiki, instalacji i service workera.
- `npm run native:sync` — build i synchronizacja lokalnych zasobów oraz pluginów do projektów natywnych.
- `npm run native:ios` / `npm run native:android` — otwarcie odpowiedniego środowiska.

## Instalacja webowa

Otwórz opublikowany adres, zaloguj się do testowego hostingu i wybierz widoczny przycisk „Zainstaluj aplikację”. W Chrome na iPhonie dokończ przez Udostępnij → Do ekranu głównego → Dodaj. Strona nie może automatycznie nacisnąć systemowego „Dodaj”. Otwórz nową ikonę online i poczekaj na gotowość offline. Wersje natywne nie mają tej bramki logowania.

## Struktura

`dist/data.js` — przepisy i oferty, `dist/model.js` — obliczenia i plan, `dist/app.js` — widoki, `dist/install-model.js` i `dist/pwa.js` — instalacja, `dist/sw.js` — offline. `src/native-bridge.js` jest źródłem generowanego `dist/native-bridge.js`. Natywne Preferences zachowują listę, ulubione i plan; Share udostępnia listę, Haptics potwierdza odznaczenie produktu. Dane nie synchronizują się między urządzeniami.

Przy zmianie plików aplikacji zwiększ wersję cache w service workerze. Pełny zestaw zasobów jest zapisywany atomowo podczas instalacji. Nie zapisuj ekranów logowania w cache. Istniejący projekt hostingowy i zakres dostępu znajdują się w `.openai/hosting.json`; zachowuj identyfikator i odbiorców.

Promocje są wprowadzane ręcznie i wygasają według daty w Polsce. Ceny dotyczą tylko potwierdzonych promocyjnych składników, a nie całego dania. Nie ma automatycznego feedu ani serwera synchronizującego dane użytkowników.

Stan przygotowania do sklepów, ograniczenia weryfikacji i dalsze wymagania: `store/RELEASE.md`. Projekty natywne są zsynchronizowane, ale nieskompilowane i niepodpisane. Właściciel musi ustalić finalne ID, konta i dane wydawcy przed wysyłką do recenzji.


## Języki i źródła przepisów

Interfejs PL, EN i UK, wybór w górnej części aplikacji, automatyczny wybór obsługiwanego języka przeglądarki, zapis lokalny i natywny. `dist/locales.js` zawiera pełne słowniki interfejsu; `dist/i18n.js` ma rejestr języków, formatowanie liczb/dat/waluty i jawny wybór dostępnego języka treści. Pozostałe języki urządzenia używają angielskiego interfejsu. Dalsze języki dodaje się przez pełny słownik i wpis w rejestrze; nie są oferowane puste tłumaczenia. Kierunek jest własnością wpisu języka i CSS ma przygotowane reguły RTL, ale brak jeszcze udostępnionego języka RTL.

Sześć nowych przepisów ma krótkie autorskie adaptacje na podstawie przeczytanych stron Good Food i Kwestii Smaku, autorów, linki, datę sprawdzenia i opis zmienionych proporcji. Ich treść jest dostępna w PL i EN. UK używa jawnie oznaczonej wersji EN dla tych sześciu przepisów, a starsze 24 przepisy redakcyjne pozostają w PL. Nie oznaczamy redakcyjnych przepisów jako potwierdzonych w internecie. Nie kopiowano zdjęć, ocen ani pełnych tekstów źródłowych. Źródła i założenia: `store/recipe-provenance.json`. Filtr „Przepisy z internetu” pokazuje wyłącznie rekordy z atrybucją.

Język zakupów nie zmienia nazw kluczy składników, wartości ani identyfikatorów przepisów w istniejącym planie. Promocje nadal dotyczą Polski i waluty PLN — wybór języka nie zmienia kraju ani cen.


## Wersja 0.5.0
120 dań, fotograficzny katalog i publikacje społeczności. Szczegóły, prawa do treści oraz ograniczenia wydania: store/RELEASE-V5.md. Backend: worker/api.js, migracje: drizzle/. `npm run dev` uruchamia lokalny podgląd z SQLite, bez tożsamości zalogowanego użytkownika. `npm run build` generuje Worker i osobny web-build dla Capacitor.
