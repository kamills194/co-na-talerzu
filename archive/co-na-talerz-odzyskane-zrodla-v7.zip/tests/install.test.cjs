const {test}=require('node:test');const assert=require('node:assert/strict');const vm=require('node:vm');const fs=require('node:fs');
const context=vm.createContext({});vm.runInContext(fs.readFileSync('dist/install-model.js','utf8'),context);
const detect=context.installationMode;
test('Chrome iPhone receives Chrome-specific home-screen instructions',()=>{
  assert.equal(detect({userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 26_0 like Mac OS X) AppleWebKit/605.1.15 CriOS/143.0 Mobile Safari/604.1'}),'ios-chrome');
});
test('Safari, touch iPad, Android, installed PWA and native apps are distinguished',()=>{
  assert.equal(detect({userAgent:'iPhone AppleWebKit Safari/605.1'}),'ios-safari');
  assert.equal(detect({userAgent:'Macintosh Safari',platform:'MacIntel',touchPoints:5}),'ios-safari');
  assert.equal(detect({userAgent:'Android Chrome/143'}),'android');
  assert.equal(detect({userAgent:'iPhone CriOS/143',standalone:true}),'installed');
  assert.equal(detect({userAgent:'iPhone',native:true}),'native');
  assert.equal(detect({userAgent:'Linux Chrome/143'}),'desktop');
});
test('native app bundles local assets without pointing at owner-private hosting',()=>{
  const config=JSON.parse(fs.readFileSync('capacitor.config.json','utf8'));
  assert.equal(config.webDir,'web-build');assert.equal(config.server.url,undefined);assert.equal(config.server.cleartext,false);
  assert.ok(fs.existsSync('ios/App/App.xcodeproj/project.pbxproj'));assert.ok(fs.existsSync('android/app/build.gradle'));
  assert.match(fs.readFileSync('android/variables.gradle','utf8'),/targetSdkVersion = 36/);
});
test('every offline shell asset exists and store icon is supplied',()=>{
  const text=fs.readFileSync('dist/sw.js','utf8');
  const shell=JSON.parse(text.match(/const SHELL = (\[[^;]+\]);/)[1].replaceAll("'",'"'));
  for(const file of shell)assert.ok(fs.existsSync('dist'+(file==='/'?'/index.html':file)),file);
  assert.ok(fs.existsSync('ios/App/App/PrivacyInfo.xcprivacy'));
  assert.match(fs.readFileSync('ios/App/App.xcodeproj/project.pbxproj','utf8'),/PrivacyInfo.xcprivacy in Resources/);
});
