const { test } = require('node:test');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const fs = require('node:fs');
const ctx = vm.createContext({ Intl, Date });
vm.runInContext(fs.readFileSync('dist/data.js','utf8') + '\n' + fs.readFileSync('dist/sourced-recipes.js','utf8') + '\n' + fs.readFileSync('dist/catalog.js','utf8') + '\n' + fs.readFileSync('dist/model.js','utf8') + '\nglobalThis.api={recipes,deals,currentDay,activeDeal,scaledQuantity,quantityLabel,addRecipeItems,promoCost,cleanPlan,itemsFromPlan};', ctx);
const m = ctx.api;
test('120 unique catalogue entries, including 30 complete local recipes',()=>{
  assert.equal(m.recipes.length,120);
  assert.equal(new Set(m.recipes.map(r=>r.id)).size,120);
  for (const r of m.recipes.filter(r=>r.source?.kind!=='catalog-reference')) {
    assert.ok(r.ingredients.length>=3 && r.steps.length>=3, r.name);
    assert.ok(['breakfast','lunch','dinner'].includes(r.meal),r.name);
    for(const i of r.ingredients) assert.ok(i.name && i.unit && Number.isFinite(i.qty) && i.qty>0,r.name);
  }
});
test('promotion expires at midnight in Poland, including while offline',()=>{
  assert.equal(m.currentDay(new Date('2026-11-18T23:00:00Z')),'2026-11-19');
  assert.equal(m.activeDeal('chicken','2026-11-18').price,24.98);
  assert.equal(m.activeDeal('chicken','2026-11-19'),undefined);
  assert.equal(m.activeDeal('tomato','2026-11-11'),undefined);
  assert.equal(m.promoCost(m.recipes[0],2,'2026-11-19'),0);
});
test('scales portions and calculates only verified promotional ingredients',()=>{
  assert.equal(m.scaledQuantity(m.recipes[0].ingredients[0],3),600);
  assert.ok(Math.abs(m.promoCost(m.recipes[0],2,'2026-11-15')-13.487)<0.00001);
  assert.ok(Math.abs(m.promoCost(m.recipes[0],3,'2026-11-15')-20.2305)<0.00001);
});
test('merges synonymous units without altering bought rows or original input',()=>{
  const before=[{name:'Oliwa',qty:1,unit:'łyżka',done:false},{name:'Oliwa',qty:2,unit:'łyżki',done:true}];
  const next=m.addRecipeItems(before,m.recipes[1],2);
  assert.equal(next.filter(x=>x.name==='Oliwa').length,2);
  assert.equal(next.find(x=>x.name==='Oliwa'&&!x.done).qty,3);
  assert.equal(next.find(x=>x.name==='Oliwa'&&x.done).qty,2);
  assert.equal(before[0].qty,1);
});
test('quantity display handles fractions and plural forms',()=>{
  assert.equal(m.quantityLabel(0.5,'ząbki'),'0,5 ząbka');
  assert.equal(m.quantityLabel(1,'łyżki'),'1 łyżka');
  assert.equal(m.quantityLabel(1.5,'łyżka'),'1,5 łyżki');
  assert.equal(m.quantityLabel(5,'ząbki'),'5 ząbków');
});

test('weekly plan validates imported or corrupted data',()=>{
  const plan=m.cleanPlan([{recipeId:1,portions:3},{recipeId:999,portions:-2},null]);
  assert.equal(plan.length,7);assert.equal(plan[0].portions,3);assert.equal(plan[1].recipeId,null);assert.equal(plan[1].portions,2);
});
test('weekly shopping list combines shared ingredients at selected portions',()=>{
  const plan=m.cleanPlan([{recipeId:1,portions:2},{recipeId:2,portions:4}]);
  const items=m.itemsFromPlan([],plan);
  assert.equal(items.find(i=>i.name==='Pomidory malinowe').qty,1700);
  assert.equal(items.find(i=>i.name==='Makaron suchy').qty,360);
  assert.equal(items.find(i=>i.name==='Polędwiczki z kurczaka').qty,400);
});

test('imported catalogue keeps real photos, original quantities and unknown yields without invented methods',()=>{const catalogue=m.recipes.filter(r=>r.source?.kind==='catalog-reference');assert.equal(catalogue.length,90);for(const r of catalogue){assert.match(r.photo.url,/^https:\/\/www.themealdb.com\/images\/media\/meals\//);assert.equal(r.time,null);assert.equal(r.baseServings,null);assert.equal(r.steps.length,0);assert.ok(r.ingredients.every(i=>typeof i.rawMeasure==='string'));}const r=catalogue[0];const items=m.addRecipeItems([],r,12);assert.equal(items[0].qty,1);assert.equal(items[0].rawMeasure,r.ingredients[0].rawMeasure);const double=m.addRecipeItems(items,r,2);assert.equal(double[0].qty,2);assert.equal(m.cleanPlan([{recipeId:r.id,portions:2}])[0].recipeId,r.id);});
test('user-provided base yield scales correctly',()=>{const r={baseServings:4,ingredients:[{name:'Pomidory',qty:1000,unit:'g'}]};assert.equal(m.addRecipeItems([],r,2)[0].qty,500);});
