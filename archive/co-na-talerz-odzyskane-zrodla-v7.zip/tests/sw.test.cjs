const {test}=require('node:test');
const assert=require('node:assert/strict');
const vm=require('node:vm');
const fs=require('node:fs');
function setup(){
  const handlers={};const saved=new Map();let mode='online';let claimed=false;
  const normalize=k=>new URL(typeof k==='string'?k:k.url,'https://app.test').pathname;
  const cache={put:async(k,r)=>saved.set(normalize(k),r.clone()),match:async k=>saved.get(normalize(k))?.clone()};
  const ctx={URL,Request,Response,console,caches:{open:async()=>cache,keys:async()=>['co-na-talerz-v1','unrelated'],delete:async()=>true},fetch:async request=>{
    if(mode==='offline')throw new TypeError('offline');
    const path=normalize(request);
    if(mode==='login')return new Response('<html>Sign in required</html>',{headers:{'content-type':'text/html'}});
    if(path==='/privacy.html')return new Response(fs.readFileSync('dist/privacy.html','utf8'),{headers:{'content-type':'text/html'}});
    if(path==='/')return new Response('<meta name="application-name" content="Co na talerz"><main>24 przepisy</main>',{headers:{'content-type':'text/html'}});
    return new Response('asset',{headers:{'content-type':path.endsWith('.png')?'image/png':'text/javascript'}});
  },self:{location:{origin:'https://app.test'},addEventListener:(n,h)=>handlers[n]=h,skipWaiting:async()=>{},clients:{claim:async()=>{claimed=true;}}}};
  vm.runInNewContext(fs.readFileSync('dist/sw.js','utf8'),ctx);
  return{handlers,saved,setMode:x=>mode=x,get claimed(){return claimed;}};
}
async function lifecycle(h,type){let p;h.handlers[type]({waitUntil:x=>p=x});await p;}
async function request(h,path,nav=true){let p;h.handlers.fetch({request:{url:'https://app.test'+path,method:'GET',mode:nav?'navigate':'cors'},respondWith:x=>p=x});return p?await p:null;}
test('installs a complete shell, claims clients and serves cached recipes offline',async()=>{
  const h=setup();await lifecycle(h,'install');await lifecycle(h,'activate');assert.equal(h.saved.size,23);assert.ok(h.claimed);
  h.setMode('offline');const r=await request(h,'/?source=homescreen');assert.equal(r.status,200);assert.match(await r.text(),/24 przepisy/);
  assert.equal((await request(h,'/data.js',false)).status,200);
});
test('never stores a login page as the offline application',async()=>{
  const h=setup();h.setMode('login');await assert.rejects(lifecycle(h,'install'));assert.equal(h.saved.size,0);
});
test('online sign-in checks take precedence over previously cached app',async()=>{
  const h=setup();await lifecycle(h,'install');h.setMode('login');assert.match(await(await request(h,'/')).text(),/Sign in required/);
  assert.equal(await request(h,'/signin-with-chatgpt?return_to=/'),null);
});
test('offline without a saved shell reports a recoverable error',async()=>{
  const h=setup();h.setMode('offline');const r=await request(h,'/');assert.equal(r.status,503);assert.match(await r.text(),/Otwórz aplikację online/);
});
