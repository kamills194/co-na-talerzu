const {test}=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const ctx=vm.createContext({Intl,Date});
vm.runInContext(['dist/data.js','dist/sourced-recipes.js','dist/catalog.js','dist/locales.js','dist/locales-v5.js','dist/ingredient-translations.js','dist/i18n.js','dist/model.js'].map(file=>fs.readFileSync(file,'utf8')).join('\n')+'\nglobalThis.api={recipes,UI_TEXT,I18N,resolveLanguage,recipeView,quantityLabel};',ctx);
const m=ctx.api;
test('supported regional languages resolve and unknown languages fall back explicitly',()=>{
 assert.equal(m.resolveLanguage(['en-GB','pl-PL']),'en');assert.equal(m.resolveLanguage('uk-UA'),'uk');assert.equal(m.resolveLanguage('pl-PL'),'pl');assert.equal(m.resolveLanguage(['ja-JP','de-DE']),'en');
});
test('all interface languages have the same nonempty translation keys and intact parameters',()=>{
 const keys=Object.keys(m.UI_TEXT.pl).sort();
 for(const lang of ['en','uk']){assert.deepEqual(Object.keys(m.UI_TEXT[lang]).sort(),keys);for(const key of keys){assert.ok(m.UI_TEXT[lang][key].trim(),key);assert.deepEqual((m.UI_TEXT[lang][key].match(/\{\w+\}/g)||[]).sort(),(key.match(/\{\w+\}/g)||[]).sort(),key);}}
});
test('English recipes stay English and untranslated recipes never silently fall back',()=>{
 const sourced=m.recipes.find(recipe=>recipe.id===25);const english=m.recipeView(sourced,'en');
 assert.equal(english.contentLang,'en');assert.equal(english.steps.length,sourced.steps.length);assert.ok(english.ingredients.every(item=>item.nameEn));
 assert.equal(m.recipeView(sourced,'uk').available,false);assert.equal(m.recipeView(m.recipes[0],'en').available,false);
});
test('six web-sourced recipes have attribution, verification dates and complete translation records',()=>{
 const sourced=m.recipes.filter(recipe=>recipe.source&&recipe.source.kind!=='catalog-reference');assert.equal(sourced.length,6);
 for(const recipe of sourced){assert.match(recipe.source.url,/^https:\/\//);assert.ok(recipe.source.author&&recipe.source.publisher&&recipe.source.adaptation&&recipe.source.adaptationEn);assert.equal(recipe.source.checkedAt,'2026-11-15');assert.equal(recipe.translations.en.steps.length,recipe.steps.length);assert.ok(recipe.ingredients.every(item=>item.nameEn));}
 assert.deepEqual(Array.from(m.recipes.slice(0,24),recipe=>recipe.id),Array.from({length:24},(_,i)=>i+1));
});
test('units and numbers localize without changing ingredient amounts',()=>{
 assert.equal(m.quantityLabel(1.5,'łyżka','en'),'1.5 tbsp');assert.equal(m.quantityLabel(2,'szt.','en'),'2 pieces');assert.equal(m.quantityLabel(250,'g','uk'),'250 г');assert.equal(m.quantityLabel(0.5,'ząbki','pl'),'0,5 ząbka');
 m.I18N.lang='en';assert.match(m.I18N.money(24.98),/PLN|zł/);assert.equal(m.I18N.t('Przepisy: {n}',{n:30}),'Recipes: 30');
});

test('catalogue titles localize while source ingredient language and lack of method remain explicit',()=>{const r=m.recipes.find(r=>r.source?.kind==='catalog-reference');assert.equal(m.recipeView(r,'pl').contentLang,'pl');assert.notEqual(m.recipeView(r,'pl').name,r.name);assert.equal(m.recipeView(r,'uk').contentLang,'uk');assert.equal(m.recipeView(r,'pl').ingredientLanguage,'en');});
