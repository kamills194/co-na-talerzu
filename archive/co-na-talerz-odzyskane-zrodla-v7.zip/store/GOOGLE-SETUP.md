# Włączenie logowania Google

Stan: integracja web jest w kodzie. Dopóki nie ustawiono prawdziwego GOOGLE_CLIENT_ID, przycisk Google nie rozpoczyna logowania, a serwer odrzuca próbę. Konto ChatGPT i publiczne przeglądanie działają osobno. Nie utworzono fikcyjnego klienta ani konta Google Cloud.

1. Na swoim koncie Google Cloud utwórz lub wybierz projekt aplikacji „Co na talerz”. Skonfiguruj Google Auth Platform: branding, audience i wymagane dane wydawcy oraz publiczne adresy polityki prywatności/pomocy. Dla publicznego wydania uwzględnij wymagania publikacji i ewentualnej weryfikacji widoczne w konsoli. Połączenie Gmail/Drive w ChatGPT nie tworzy tego klienta aplikacji.
2. Utwórz OAuth client ID typu **Web application**.
3. Dodaj Authorized JavaScript origin dokładnie:
   https://co-na-talerz-kamil.przestrze-ro-2040.chatgpt.site
4. Obecna integracja korzysta z Google Identity Services z odpowiedzią JavaScript (popup/callback), nie z przekierowania OAuth. Nie rejestruj /callback należącego do hostingu ChatGPT. Weryfikacja tokena trafia POST-em do /api/auth/google na tym samym originie. Redirect URI nie jest używany w tej konfiguracji.
5. Przekaż **publiczny Client ID**, kończący się na `.apps.googleusercontent.com`. Nie przekazuj hasła, client secret ani klucza prywatnego. Ustawimy GOOGLE_CLIENT_ID przez ustawienia środowiska i wdrożymy istniejącą wersję z nową konfiguracją.
6. Na rzeczywistym iPhonie/Androidzie i komputerze przetestuj: przycisk Google, zatwierdzenie dostępu, sesję po odświeżeniu, wylogowanie i usunięcie danych. Minimalne dane logowania: identyfikator i nazwa; bez uprawnień do Gmaila, plików czy kontaktów.

Google w natywnym WebView nie jest wdrożonym natywnym logowaniem: interfejs kieruje do webowej wersji. Wydanie sklepowe będzie wymagało właściwego przepływu natywnego/systemowej przeglądarki i osobnych testów. Nie twierdzimy, że samo podłączenie Client ID kończy przygotowanie do sklepów.

Oficjalne instrukcje:
https://developers.google.com/identity/gsi/web/guides/get-google-api-clientid
https://developers.google.com/identity/gsi/web/guides/verify-google-id-token
