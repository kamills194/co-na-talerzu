# 0.5.1 / build 6

Six primary meal occasions across the existing 120 dishes: breakfast 10, second breakfast 9, lunch 58, dessert 9, starters 16, dinner 18. Editorial navigation assignments in src/meal-types.js preserve source categories separately. Catalogue cards, meal tiles, search and surprise selection share the same categoryOf function. Ingredient-type filtering remains secondary.

Community authors choose a meal category. D1 additive migration 0001 adds meal with lunch default for existing publications. Server validates and persists the selected category. Previous content, ownership and withdrawal behavior stay compatible.

Checked 33 tests including full catalogue coverage, representative meal assignments and round-trip persistence. Native source synced; no signed device builds. Prior v5 release limitations still apply.
