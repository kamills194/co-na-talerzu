# Przygotowanie do sklepów

Wersja 0.4.0, build 4, stan na 15 listopada 2026. To baza do wydania testowego, bez podpisanych binariów i bez potwierdzonej gotowości do wysłania do recenzji.

## Gotowe w kodzie

- Projekty `android/` i `ios/`, Capacitor 8, wspólne lokalne zasoby z `dist/`. Brak `server.url`: nie jest to zdalna strona wymagająca konta ChatGPT. Podstawowe funkcje natywne nie wymagają logowania ani pierwszego pobrania przepisów.
- Android: compile/target SDK 36, minimum SDK 24, versionCode 4, versionName 0.4.0. Wyłączony cleartext i systemowy backup Androida. Jedynym uprawnieniem w manifeście aplikacji jest INTERNET; przejrzyj również finalny merged manifest.
- iOS: projekt Xcode ze Swift Package Manager, minimum iOS 15, wersja 0.4.0/build 4, polska nazwa, własna ikona i splash. Do zasobów projektu dodano PrivacyInfo.xcprivacy z UserDefaults/CA92.1 dla Preferences. Podstawowy runtime Capacitor i biblioteki mogą mieć własne manifesty; końcowy raport prywatności sprawdza się po archiwizacji.
- Natywne Preferences do zachowania listy, ulubionych i planu; Share do wysyłania listy na wyraźne polecenie użytkownika; Haptics do potwierdzania odznaczenia produktu. Wersja webowa pozostaje PWA.
- 30 przepisów, filtry, ulubione, skala porcji, plan tygodnia i zbiorcza lista zakupów. Usuwanie lokalnych danych z potwierdzeniem. Instrukcje Chrome i Safari na iPhonie.
- Ikony sklepowe w `store/assets/`, roboczy opis w `store/listing-pl.json`, dostępny w aplikacji opis prywatności.

## Sprawdzone

`npm test`: 20 testów — obliczenia, wygasanie promocji według czasu w Polsce, łączenie zakupów, walidacja planu, rozpoznawanie Chrome iPhone/Safari/Android/PWA/native, pliki instalacyjne oraz cache offline i odrzucanie strony logowania.

`npm run build` oraz `npx cap sync` zakończone powodzeniem. Przeglądarka: duży przycisk instalacji, instrukcja Chrome na iPhonie, planowanie kilku dni, lista ze zsumowanymi ilościami oraz ponowne uruchomienie. To test webowej części aplikacji w szerokości telefonu, a nie test fizycznego iPhone’a ani natywnego Androida.

## Przed TestFlight i testami Google Play

1. Ustalić wydawcę, finalne identyfikatory pakietów (obecny `pl.conatalerz.app` jest roboczy), dane kontaktowe i własność nazwy. Uzupełnić puste pola `listing-pl.json`.
2. Przygotować konta Apple Developer i Google Play Console oraz podpisy. Nie ma w repozytorium certyfikatów, keystore, haseł ani profili provisioning.
3. W macOS z Xcode 26+ wykonać `npm ci`, `npm run native:sync`, `npm run native:ios`, wybrać zespół deweloperski i stworzyć archiwum/TestFlight. W tym środowisku Linux nie ma Xcode, więc nie wykonano kompilacji iOS.
4. W Android Studio 2025.2.1+ z SDK 36 wykonać `npm ci`, `npm run native:sync`, `npm run native:android`, zbudować debug do testów, a następnie podpisany AAB. W tym środowisku nie ma skonfigurowanego Android SDK/emulatora i nie wykonano kompilacji Androida.
5. Przetestować rzeczywiste urządzenia: start bez sieci od pierwszego uruchomienia natywnej aplikacji, trwałość Preferences po ubiciu procesu, udostępnianie i anulowanie Share, Haptics, bezpieczne otwieranie gazetek, obroty ekranu, czytnik ekranu, duży tekst, klawiaturę i obszary bezpieczne. Testy modeli nie zastępują testów pluginów.

## Przed publikacją produkcyjną

- Udostępnić publiczny URL pomocy i pełnej polityki prywatności wydawcy. Testowy hosting Sites jest owner-private, więc jego chroniony adres nie wystarcza jako publiczna polityka dla sklepów. Nie zmieniono widoczności projektu.
- Wypełnić App Privacy, Google Play Data safety, kategorię wiekową i deklaracje treści zgodnie z finalnym buildem, SDK i zachowaniem hostingu. Opis lokalnego przetwarzania nie jest automatycznie gotową deklaracją sklepową.
- Przygotować prawdziwe zrzuty ekranowe z finalnych urządzeń, zweryfikować opisy i ceny. Nie używać makiet PWA jako dowodu działania builda natywnego.
- Sprawdzić terminy i warunki ofert; obecna baza ma dwie ręcznie sprawdzone oferty Auchan z końcem 18 listopada 2026 i nie ma automatycznego feedu. Przed szerszym startem zdecydować o źródle aktualizowanych promocji.
- Zweryfikować prawa do przepisów i zasobów oraz wymagania recenzji. Lokalny plan, zakupy i natywne udostępnianie dodają użyteczność, ale samo opakowanie strony w aplikację nie gwarantuje zatwierdzenia przez Apple.

## Oficjalne odniesienia

- https://support.google.com/chrome/answer/9658361?co=GENIE.Platform%3DiOS&hl=en
- https://capacitorjs.com/docs/getting-started/environment-setup
- https://capacitorjs.com/docs/apis/preferences
- https://capacitorjs.com/docs/ios/privacy-manifest
- https://developer.apple.com/app-store/review/guidelines/ (4.2 i 5.1)
- https://developer.apple.com/help/app-store-connect/manage-app-information/manage-app-privacy/
- https://support.google.com/googleplay/android-developer/answer/11926878
- https://support.google.com/googleplay/android-developer/answer/9859455


## Uzupełnienie wersji 0.4.0

Dostępne języki interfejsu: polski, angielski i ukraiński. Nowe sześć adaptacji ze źródłami ma treść PL/EN; pozostałe języki treści są jawnie wskazane w interfejsie. Przepisy 1–24 nadal redakcyjne i polskojęzyczne. Rejestr identyfikatorów jest zachowany, a ustawienie języka nie czyści danych. Weryfikacja: 20 testów, zmiana języków w podglądzie telefonu, odczyt autora i źródła, skala porcji i zachowanie tygodniowego planu po ponownym uruchomieniu. Natywna synchronizacja nie zastępuje testów urządzeń ani końcowego przeglądu tłumaczeń przed publikacją w danym języku.
