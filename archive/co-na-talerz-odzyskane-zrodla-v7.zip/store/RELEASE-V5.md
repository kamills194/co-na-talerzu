# Co na talerz 0.5.0 / build 5

Private test release. Same Site ID and audience retained.

- Catalogue: 120 dishes. 30 full local recipes (including 6 source adaptations) plus 90 attributed catalogue references with real provider photographs, original ingredients and links to full methods. New references do not invent timing or serving counts and cannot scale source quantities. Ingredient text is English; dish titles have Polish/English versions. No full third-party methods were copied.
- Photographs: exact strMealThumb URLs from TheMealDB official API, fetched 2026-11-15. Visible credit and source links. Original API records did not confirm Creative Commons status. API test key permits development; before public production / app stores obtain the required provider subscription and review artwork and third-party rights. See catalog-provenance.json. No generated food photos.
- Community: Worker ESM, D1 immutable Drizzle migration, R2 photos. Sites trusted user identity, same-origin writes, server validation, ownership checks, text drafts, upload re-encoding in UI, withdrawal and image deletion, reports and author hiding. No fabricated user posts. Reports are stored; an operator moderation console, support contacts, abuse response workflow and appeals remain required before a public community launch. Users currently cannot erase server history themselves; provide a deletion/support workflow and retention policy before public release.
- Current Site audience is owner-private. Public community discovery requires an explicit sharing change later. Native app keeps local catalogue but publishing uses authenticated web edition; shared native login and public read API are not implemented. No claim of public UGC readiness.
- Retail: 6 official leaflet hubs (Biedronka, Lidl, Kaufland, Auchan, Carrefour, ALDI), plus the prior two manually verified ingredient-price offers. Leaflet links are not a live extracted price feed. Offers expire by Poland date.
- Native projects: version bumped and Capacitor synced from web-build (excludes server bundle). Xcode/archive/signing and Android device builds are not available here. Not uploaded to App Store or Google Play. Prior release requirements still apply, including updated privacy labels for published content and moderation.
- Offline: app shell and catalogue metadata local; photographs, original methods, leaflets and community require network. Offline shell never stores sign-in pages. No offline publication queue.

## Rebuild
npm ci
npm test
npm run build
npx cap sync

Generated SQL migrations in drizzle/ are applied by Sites at deployment. Local preview applies them at startup, never during requests. Node 24 local dev SQLite mirrors D1 SQL. Local preview does not spoof hosted identity.
