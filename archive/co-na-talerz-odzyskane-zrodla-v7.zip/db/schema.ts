import { sqliteTable, text, integer, index, uniqueIndex } from 'drizzle-orm/sqlite-core';
export const communityRecipes=sqliteTable('community_recipes',{
 id:text('id').primaryKey(),ownerId:text('owner_id').notNull(),author:text('author').notNull(),title:text('title').notNull(),description:text('description').notNull(),ingredients:text('ingredients_json').notNull(),steps:text('steps_json').notNull(),servings:integer('servings').notNull(),minutes:integer('minutes').notNull(),diet:text('diet').notNull(),meal:text('meal').notNull().default('lunch'),language: text('language').notNull().default('pl'),
  photoKey:text('photo_key'),status:text('status').notNull().default('published'),createdAt:text('created_at').notNull(),updatedAt:text('updated_at').notNull()
},table=>[index('community_published_idx').on(table.status,table.createdAt),index('community_owner_idx').on(table.ownerId)]);
export const communityReports=sqliteTable('community_reports',{
 id:text('id').primaryKey(),recipeId:text('recipe_id').notNull(),reporterId:text('reporter_id').notNull(),reason:text('reason').notNull(),createdAt:text('created_at').notNull()
},table=>[uniqueIndex('community_report_unique').on(table.recipeId,table.reporterId)]);
export const communityBlocks=sqliteTable('community_blocks',{
 id:text('id').primaryKey(),userId:text('user_id').notNull(),blockedAuthorId:text('blocked_author_id').notNull(),createdAt:text('created_at').notNull()
},table=>[uniqueIndex('community_block_unique').on(table.userId,table.blockedAuthorId)]);

export const promoOffers=sqliteTable('promo_offers',{
 id:text('id').primaryKey(),storeId:text('store_id').notNull(),name:text('name').notNull(),ingredientKey:text('ingredient_key'),price:integer('price_cents').notNull(),unit:text('unit').notNull(),start:text('start_date').notNull(),end:text('end_date').notNull(),conditions:text('conditions').notNull(),scope:text('scope').notNull(),sourceUrl:text('source_url').notNull(),evidence:text('evidence').notNull(),checkedAt:text('checked_at').notNull(),updatedAt:text('updated_at').notNull()
},table=>[index('promo_dates_idx').on(table.start,table.end)]);
export const promoSources=sqliteTable('promo_sources',{
 storeId:text('store_id').primaryKey(),url:text('url').notNull(),status:text('status').notNull(),contentHash:text('content_hash'),checkedAt:text('checked_at').notNull(),changedAt:text('changed_at'),leaflets:text('leaflets_json').notNull(),message:text('message').notNull()
});
export const promoRuns=sqliteTable('promo_runs',{
 id:text('id').primaryKey(),startedAt:text('started_at').notNull(),finishedAt:text('finished_at'),status:text('status').notNull(),summary:text('summary_json').notNull()
});
export const loginUsers=sqliteTable('login_users',{
 id:text('id').primaryKey(),name:text('name').notNull(),createdAt:text('created_at').notNull()
});
export const loginSessions=sqliteTable('login_sessions',{
 hash:text('hash').primaryKey(),userId:text('user_id').notNull(),expiresAt:text('expires_at').notNull(),createdAt:text('created_at').notNull()
},table=>[index('login_session_expiry').on(table.expiresAt)]);
export const loginNonces=sqliteTable('login_nonces',{
 hash:text('hash').primaryKey(),expiresAt:text('expires_at').notNull()
});
