package pl.conatalerz.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
