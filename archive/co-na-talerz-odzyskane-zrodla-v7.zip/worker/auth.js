import {createRemoteJWKSet,jwtVerify} from 'jose';
const keys=createRemoteJWKSet(new URL('https://www.googleapis.com/oauth2/v3/certs'));
const hex=bytes=>Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
export const hash=async s=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))));
export const random=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
const cookie=(name,value,age)=>`${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${age}`;
const cookies=req=>Object.fromEntries((req.headers.get('cookie')||'').split(';').map(s=>s.trim().split('=')));
const json=(body,status=200,headers={})=>new Response(JSON.stringify(body),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store',...headers}});
export function isOwner(request,env){return !!env.OWNER_EMAIL&&request.headers.get('oai-authenticated-user-email')?.toLowerCase()===env.OWNER_EMAIL.toLowerCase();}
export async function identity(request,env){const site=request.headers.get('oai-authenticated-user-id');if(site)return{id:site,provider:'chatgpt',name:'ChatGPT',admin:isOwner(request,env)};const token=cookies(request)['__Host-cnt-session'];if(!token||!env.DB)return null;const row=await env.DB.prepare('SELECT s.user_id,u.name FROM login_sessions s JOIN login_users u ON u.id=s.user_id WHERE s.hash=? AND s.expires_at>?').bind(await hash(token),new Date().toISOString()).first();return row?{id:row.user_id,name:row.name,provider:'google',admin:false}:null;}
export async function authRoute(request,env,verify=credential=>jwtVerify(credential,keys,{audience:env.GOOGLE_CLIENT_ID,issuer:['https://accounts.google.com','accounts.google.com'],algorithms:['RS256'],requiredClaims:['sub','iat','exp','nonce']})){
 const url=new URL(request.url),path=url.pathname;
 if(path==='/api/auth/config')return json({googleEnabled:!!env.GOOGLE_CLIENT_ID,googleClientId:env.GOOGLE_CLIENT_ID||null,chatgptEnabled:true});
 if(!env.DB)return json({error:'Logowanie chwilowo niedostępne.'},503);
 if(path==='/api/auth/google/challenge'&&request.method==='POST'){
  if(!env.GOOGLE_CLIENT_ID)return json({error:'Logowanie Google nie jest jeszcze włączone.'},503);
  if(request.headers.get('origin')!==url.origin)return json({error:'Nieprawidłowe pochodzenie żądania.'},403);
  const nonce=random();await env.DB.prepare('INSERT INTO login_nonces(hash,expires_at) VALUES(?,?)').bind(await hash(nonce),new Date(Date.now()+300000).toISOString()).run();return json({nonce},200,{'Set-Cookie':cookie('__Host-cnt-nonce',nonce,300)});
 }
 if(path==='/api/auth/google'&&request.method==='POST'){
  if(!env.GOOGLE_CLIENT_ID)return json({error:'Logowanie Google nie jest jeszcze włączone.'},503);
  if(request.headers.get('origin')!==url.origin)return json({error:'Nieprawidłowe pochodzenie żądania.'},403);
  try{
   const body=await request.json();if(typeof body.credential!=='string'||body.credential.length>16000)throw Error('token');
   const nonce=cookies(request)['__Host-cnt-nonce'];if(!nonce)throw Error('nonce');
   const {payload}=await verify(body.credential);if(payload.nonce!==nonce||typeof payload.sub!=='string'||payload.sub.length>255||typeof payload.exp!=='number'||payload.exp*1000<=Date.now())throw Error('claims');
   const consumed=await env.DB.prepare('DELETE FROM login_nonces WHERE hash=? AND expires_at>? RETURNING hash').bind(await hash(nonce),new Date().toISOString()).first();if(!consumed)throw Error('replay');
   const id='google-'+await hash(payload.sub),name=String(payload.name||'Użytkownik Google').slice(0,80),now=new Date().toISOString();
   await env.DB.prepare('INSERT INTO login_users(id,name,created_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name').bind(id,name,now).run();
   const token=random();await env.DB.prepare('INSERT INTO login_sessions(hash,user_id,expires_at,created_at) VALUES(?,?,?,?)').bind(await hash(token),id,new Date(Date.now()+604800000).toISOString(),now).run();
   const headers=new Headers({'Content-Type':'application/json','Cache-Control':'no-store'});headers.append('Set-Cookie',cookie('__Host-cnt-session',token,604800));headers.append('Set-Cookie',cookie('__Host-cnt-nonce','',0));return new Response(JSON.stringify({authenticated:true,name}),{headers});
  }catch{return json({error:'Nie udało się potwierdzić logowania Google. Spróbuj ponownie.'},401);}
 }
 if(path==='/api/auth/logout'&&request.method==='POST'){
  if(request.headers.get('origin')!==url.origin)return json({error:'Nieprawidłowe pochodzenie żądania.'},403);const token=cookies(request)['__Host-cnt-session'];if(token)await env.DB.prepare('DELETE FROM login_sessions WHERE hash=?').bind(await hash(token)).run();return json({signedOut:true},200,{'Set-Cookie':cookie('__Host-cnt-session','',0)});
 }
 return json({error:'Nie znaleziono.'},404);
}
