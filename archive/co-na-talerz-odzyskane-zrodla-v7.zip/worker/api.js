import {identity,isOwner,authRoute} from './auth.js';
import operatorInstructions from '../bot/operator-instructions.json' with {type:'json'};
import {authorizedUpdater,updatePromotions,readPromotions} from './promotions.js';
import {MEAL_TYPES} from '../src/meal-types.js';
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status});};

const clean=(value,max,min=1)=>typeof value==='string'&&value.trim().length>=min&&value.trim().length<=max?value.trim():fail('Sprawdź długość i treść pól.');
export function validateRecipe(value){
 const meal=value.meal===undefined?'lunch':value.meal;
 if(!MEAL_TYPES.some(type=>type.id===meal))fail('Wybierz kategorię posiłku.');
 const title=clean(value.title,100,4),author=clean(value.author,40,2),description=clean(value.description,500,10);
 const servings=Number(value.servings),minutes=Number(value.minutes);
 if(!Number.isInteger(servings)||servings<1||servings>12||!Number.isInteger(minutes)||minutes<5||minutes>600)fail('Podaj 1–12 porcji i czas 5–600 minut.');
 if(!['veg','meat','fish','other'].includes(value.diet))fail('Wybierz rodzaj dania.');
 if(!['pl','en','uk'].includes(value.language))fail('Wybierz język przepisu.');
 if(!Array.isArray(value.ingredients)||value.ingredients.length<2||value.ingredients.length>40)fail('Dodaj od 2 do 40 składników.');
 const ingredients=value.ingredients.map(i=>{const name=clean(i.name,100);const qty=Number(i.qty);if(!Number.isFinite(qty)||qty<=0||qty>100000||!['g','ml','szt.','łyżka','łyżeczka','ząbek','kromka','pęczek','garść'].includes(i.unit))fail('Sprawdź ilości i jednostki składników.');return{name,qty,unit:i.unit};});
 if(!Array.isArray(value.steps)||value.steps.length<2||value.steps.length>25)fail('Opisz przygotowanie w 2–25 krokach.');
 const steps=value.steps.map(s=>clean(s,2000,5));
 if(value.rights!==true)fail('Potwierdź prawa do publikowanych treści.');
 return{title,author,description,servings,minutes,meal,diet:value.diet,language:value.language,ingredients,steps};
}
function publicRecipe(row,user){return{id:'community-'+row.id,name:row.title,desc:row.description,author:row.author,originalLanguage:row.language||'pl',ingredientLanguage:row.language||'pl',ingredients:JSON.parse(row.ingredients_json),steps:JSON.parse(row.steps_json),time:row.minutes,baseServings:row.servings,diet:row.diet,meal:row.meal||'lunch',category:'Community',isCommunity:true,isMine:row.owner_id===user,status:row.status,createdAt:row.created_at,photo:row.photo_key?{url:'/media/'+row.photo_key,credit:row.author}:null};}
async function owned(env,id,user){const row=await env.DB.prepare('SELECT * FROM community_recipes WHERE id = ?').bind(id).first();if(!row)fail('Nie znaleziono przepisu.',404);if(row.owner_id!==user)fail('Możesz zmieniać tylko własny przepis.',403);return row;}
export async function api(request,env){
 try{
  const url=new URL(request.url),path=url.pathname,method=request.method;
  if(path.startsWith('/api/auth/'))return authRoute(request,env);
  if(path==='/api/bot/instructions'&&method==='GET'){if(!await authorizedUpdater(request,env))return json({error:'Brak uprawnień.'},403);return json(operatorInstructions);}
  if(path==='/api/bot/run'&&method==='POST')return updatePromotions(request,env);
  if(path==='/api/promotions'&&method==='GET')return Response.json(await readPromotions(env),{headers:{'Cache-Control':'no-store','Access-Control-Allow-Origin':'*'}});
  const account=await identity(request,env),user=account?.id,admin=isOwner(request,env);
  if(path==='/api/session'&&method==='GET')return json({authenticated:!!user,canPublish:!!user&&!!env.DB&&!!env.BUCKET,name:account?.name||null,provider:account?.provider||null,admin});
  if(path==='/api/health'&&method==='GET'){if(!env.DB||!env.BUCKET)return json({ready:false},503);await env.DB.prepare('SELECT count(*) AS n FROM community_recipes').first();return json({ready:true});}
  if(!env.DB||!env.BUCKET)fail('Publikacje są chwilowo niedostępne. Zapisz szkic i spróbuj później.',503);
  if(path.startsWith('/media/')&&method==='GET'){
   const key=path.slice(7);if(!/^[a-f0-9-]{36}\.(jpg|png|webp)$/.test(key))fail('Nie znaleziono zdjęcia.',404);
   const row=await env.DB.prepare("SELECT owner_id,status FROM community_recipes WHERE photo_key = ?").bind(key).first();if(!row||(row.status!=='published'&&row.owner_id!==user&&!admin))fail('Nie znaleziono zdjęcia.',404);
   const file=await env.BUCKET.get(key);if(!file)fail('Nie znaleziono zdjęcia.',404);
   return new Response(file.body,{headers:{'Content-Type':file.httpMetadata?.contentType||'image/jpeg','Cache-Control':'private, max-age=300','X-Content-Type-Options':'nosniff'}});
  }
  if(!['GET','HEAD'].includes(method)){
   if(!user)fail('Zaloguj się, aby opublikować przepis.',401);
   if(request.headers.get('origin')!==url.origin)fail('Otwórz formularz w aplikacji i spróbuj ponownie.',403);
  }
  if(path==='/api/account'&&method==='DELETE'){
   const ownedPhotos=await env.DB.prepare('SELECT photo_key FROM community_recipes WHERE owner_id=? AND photo_key IS NOT NULL').bind(user).all();
   for(const row of ownedPhotos.results)await env.BUCKET.delete(row.photo_key);
   for(const [table,column] of [['community_recipes','owner_id'],['community_reports','reporter_id'],['community_blocks','user_id'],['login_sessions','user_id'],['login_users','id']])await env.DB.prepare(`DELETE FROM ${table} WHERE ${column}=?`).bind(user).run();
   await env.DB.prepare('DELETE FROM community_blocks WHERE blocked_author_id=?').bind(user).run();
   return json({deleted:true},200);
  }
  if(path==='/api/admin/moderation'&&method==='GET'){
   if(!admin)fail('Brak uprawnień.',403);
   const {results}=await env.DB.prepare("SELECT * FROM community_recipes WHERE status='pending' OR (status='published' AND id IN (SELECT recipe_id FROM community_reports)) ORDER BY created_at LIMIT 50").all();
   return json({recipes:results.map(row=>publicRecipe(row,user))});
  }
  const review=path.match(/^\/api\/admin\/moderation\/([a-f0-9-]{36})$/);
  if(review&&method==='POST'){
   if(!admin)fail('Brak uprawnień.',403);const body=await request.json();if(!['approve','reject'].includes(body.action))fail('Nieprawidłowa decyzja.');
   const row=await env.DB.prepare('SELECT photo_key FROM community_recipes WHERE id=?').bind(review[1]).first();if(!row)fail('Nie znaleziono.',404);
   if(body.action==='approve')await env.DB.prepare("UPDATE community_recipes SET status='published',updated_at=? WHERE id=?").bind(new Date().toISOString(),review[1]).run();
   else{await env.DB.prepare("UPDATE community_recipes SET status='withdrawn',photo_key=NULL,updated_at=? WHERE id=?").bind(new Date().toISOString(),review[1]).run();if(row.photo_key)await env.BUCKET.delete(row.photo_key);}
   await env.DB.prepare('DELETE FROM community_reports WHERE recipe_id=?').bind(review[1]).run();return json({updated:true});
  }
  if(path==='/api/community'&&method==='GET'){
   const mine=url.searchParams.get('mine')==='1';if(mine&&!user)fail('Zaloguj się, aby zobaczyć swoje publikacje.',401);
   const offset=Math.min(10000,Math.max(0,Math.trunc(Number(url.searchParams.get('offset')))||0));
   const language=url.searchParams.get('language');if(language&&!['pl','en','uk'].includes(language))fail('Nieprawidłowy język.');
   const condition=language?' AND language=?':'';
   const sql=mine?`SELECT * FROM community_recipes WHERE owner_id = ?${condition} ORDER BY created_at DESC,id DESC LIMIT 13 OFFSET ?`:`SELECT * FROM community_recipes WHERE status = 'published' AND owner_id NOT IN (SELECT blocked_author_id FROM community_blocks WHERE user_id = ?)${condition} ORDER BY created_at DESC,id DESC LIMIT 13 OFFSET ?`;
   const args=language?[user||'',language,offset]:[user||'',offset];const {results}=await env.DB.prepare(sql).bind(...args).all();
   return json({recipes:results.slice(0,12).map(row=>publicRecipe(row,user)),hasMore:results.length>12});
  }
  if(path==='/api/community'&&method==='POST'){
   if(Number(request.headers.get('content-length')||0)>6*1024*1024)fail('Zdjęcie jest zbyt duże.',413);
   const now=new Date().toISOString();const dayAgo=new Date(Date.now()-86400000).toISOString();
   const count=await env.DB.prepare('SELECT count(*) AS n FROM community_recipes WHERE owner_id = ? AND created_at > ?').bind(user,dayAgo).first();if(count.n>=20)fail('Limit to 20 publikacji na dobę. Wróć później.',429);
   const reader=request.body.getReader();const chunks=[];let total=0;while(true){const part=await reader.read();if(part.done)break;total+=part.value.byteLength;if(total>6*1024*1024){await reader.cancel();fail('Formularz jest za duży.',413);}chunks.push(part.value);}const data=await new Response(new Blob(chunks),{headers:{'Content-Type':request.headers.get('content-type')||''}}).formData();let input;try{input=JSON.parse(data.get('recipe'));}catch{fail('Nieprawidłowy formularz.');}const recipe=validateRecipe(input);
   const photo=data.get('photo');let key=null,contentType=null,bytes;
   if(photo&&typeof photo!=='string'&&photo.size){
    if(photo.size>5*1024*1024)fail('Zdjęcie może mieć maksymalnie 5 MB.',413);
    bytes=new Uint8Array(await photo.arrayBuffer());
    if(bytes[0]===255&&bytes[1]===216&&bytes[2]===255){key=crypto.randomUUID()+'.jpg';contentType='image/jpeg';}
    else if([137,80,78,71,13,10,26,10].every((v,i)=>bytes[i]===v)){key=crypto.randomUUID()+'.png';contentType='image/png';}
    else if(new TextDecoder().decode(bytes.slice(0,4))==='RIFF'&&new TextDecoder().decode(bytes.slice(8,12))==='WEBP'){key=crypto.randomUUID()+'.webp';contentType='image/webp';}
    else fail('Wybierz zdjęcie JPG, PNG lub WebP.');
   }
   const id=crypto.randomUUID();const publicationStatus=admin||!env.PUBLIC_BETA?'published':'pending';
   if(key)await env.BUCKET.put(key,bytes,{httpMetadata:{contentType}});
   try{await env.DB.prepare('INSERT INTO community_recipes (id,owner_id,author,title,description,ingredients_json,steps_json,servings,minutes,diet,meal,language,photo_key,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,user,recipe.author,recipe.title,recipe.description,JSON.stringify(recipe.ingredients),JSON.stringify(recipe.steps),recipe.servings,recipe.minutes,recipe.diet,recipe.meal,recipe.language,key,publicationStatus,now,now).run();}catch(error){if(key)await env.BUCKET.delete(key);throw error;}
   const row=await owned(env,id,user);return json({recipe:publicRecipe(row,user)},201);
  }
  const match=path.match(/^\/api\/community\/([a-f0-9-]{36})(?:\/(report|block))?$/);
  if(match){const [,id,action]=match;
   if(method==='DELETE'&&!action){const row=await owned(env,id,user);await env.DB.prepare("UPDATE community_recipes SET status = 'withdrawn',photo_key = NULL,updated_at = ? WHERE id = ? AND owner_id = ?").bind(new Date().toISOString(),id,user).run();if(row.photo_key)await env.BUCKET.delete(row.photo_key);return json({withdrawn:true});}
   if(method==='POST'&&action){
    const row=await env.DB.prepare("SELECT owner_id FROM community_recipes WHERE id = ? AND status = 'published'").bind(id).first();if(!row)fail('Nie znaleziono przepisu.',404);if(row.owner_id===user)fail('To Twój przepis. Możesz go wycofać.');
    if(action==='report'){const body=await request.json();const reason=clean(body.reason,500,5);await env.DB.prepare('INSERT OR IGNORE INTO community_reports (id,recipe_id,reporter_id,reason,created_at) VALUES (?,?,?,?,?)').bind(crypto.randomUUID(),id,user,reason,new Date().toISOString()).run();return json({reported:true});}
    await env.DB.prepare('INSERT OR IGNORE INTO community_blocks (id,user_id,blocked_author_id,created_at) VALUES (?,?,?,?)').bind(crypto.randomUUID(),user,row.owner_id,new Date().toISOString()).run();return json({blocked:true});
   }
  }
  return json({error:'Nie znaleziono.'},404);
 }catch(error){return json({error:error.status?error.message:'Usługa jest chwilowo niedostępna. Spróbuj ponownie.'},error.status||503);}
}
